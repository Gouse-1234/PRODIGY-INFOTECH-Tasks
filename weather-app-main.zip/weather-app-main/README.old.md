# Project---Weather-App
This project is created using MERN stack
